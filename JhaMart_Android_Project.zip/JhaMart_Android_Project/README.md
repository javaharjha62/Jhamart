# JhaMart Android App Project

This project wraps the supplied JhaMart V16 HTML prototype as an Android app using Capacitor.

## Build on a computer
1. Install Node.js and Android Studio/Android SDK.
2. In this folder run:
   npm install
3. Add/sync Android:
   npx cap add android
   npx cap sync android
4. Open Android Studio:
   npx cap open android
5. Build a debug APK from Android Studio, or run:
   cd android
   ./gradlew assembleDebug

Package ID: `com.jhamart.app`

The current HTML prototype uses browser/localStorage-style demo data. Real server database, payment gateway, authentication, seller/admin APIs, and delivery integration still need backend integration before production use.
