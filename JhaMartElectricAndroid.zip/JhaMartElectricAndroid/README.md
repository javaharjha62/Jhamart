# JhaMart Electric Android App

This Android Studio project wraps the supplied JhaMart V16 HTML prototype in a native Android WebView.

## Open/build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone with USB debugging or use an emulator.
4. Press Run to install the debug app.
5. For an APK: Build > Build APK(s).

## Demo accounts from the prototype
Seller: seller / 1234
Admin: admin / 1234

## Important
The supplied HTML prototype stores data in browser/local storage and uses demo payment flows. This Android conversion does not turn those demo flows into real secure payments, cloud accounts, seller payouts, or delivery APIs. Those require a backend and production integrations.
